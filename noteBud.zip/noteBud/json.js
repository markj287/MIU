//json object
//Mark Johnson
// This will populate our form so we can have easy access to local storage data. Quite frankly am lazy.

var json = {
	"note1": {
		"groups": ["Groups:", "Entertainment"],
		"notetitle": ["Title:","Go See a Movie This Weekend"],
		"noteinfo": ["Note:","Me and my girlfriend will double date this weekend. Dinner and movie."],
		"date": ["Date:","June 16, 2012"],
		"items": ["Number of Items:","4"],
		"attach": ["Attach a File:",""],
		"favorite": ["Favorite Note:","Yes"]
	},
	"note2": {
		"groups": ["Groups:", "Grocery"],
		"notetitle": ["Title:","Grocery Shopping"],
		"noteinfo": ["Note:","I have to pick up a few items at walmart on thursday."],
		"date": ["Date:","June 14, 2012"],
		"items": ["Number of Items:","19"],
		"attach": ["Attach a File:",""],
		"favorite": ["Favorite Note:","Yes"]
	},
	"note3": {
		"groups": ["Groups:", "Shopping"],
		"notetitle": ["Title:","Clothes Shopping"],
		"noteinfo": ["Note:","I have to buy a fresh outfit for the club this weekend."],
		"date": ["Date:","June 17, 2012"],
		"items": ["Number of Items:","5"],
		"attach": ["Attach a File:",""],
		"favorite": ["Favorite Note:","Yes"]
	}
}
